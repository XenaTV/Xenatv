#!/usr/bin/env python3
"""Atualiza o projeto Android já restaurado pela workflow compacta XenaTV 6.9."""
from pathlib import Path
from PIL import Image
import sys
base=Path('xena-premium/XenaTV_Android/app/src/main')
java=base/'java/br/com/xenatv/app'
res=base/'res/drawable-nodpi'
res.mkdir(parents=True,exist_ok=True)

def replace_once(s,old,new,label):
    n=s.count(old)
    if n!=1: raise RuntimeError(f'{label}: esperado 1 trecho, encontrado {n}')
    return s.replace(old,new,1)

# Recortes do desenho aprovado pelo usuário, não ícones genéricos.
img=Image.open(Path(__file__).with_name('1000510040.jpg')).convert('RGBA')
boxes={
 'home':(641,100,904,337), 'tv':(356,376,524,528),
 'movies':(593,378,749,526),'series':(816,377,978,526),
 'favorites':(1037,379,1183,526),'games':(348,580,520,735),
 'options':(587,586,744,727),'menu':(821,602,958,714),
 'search':(1038,588,1187,725),
}
for key,box in boxes.items():
    cropped=img.crop(box)
    cropped.thumbnail((256,256),Image.Resampling.LANCZOS)
    cropped.save(res/f'xena_nav_{key}.png',optimize=True)

p=java/'MainActivity.java';s=p.read_text()
marker='    private void refreshDock(){'
helper='''    private int xenaNavIcon(String destination){
        if(HOME.equals(destination))return R.drawable.xena_nav_home;
        if(TV.equals(destination))return R.drawable.xena_nav_tv;
        if(MOVIES.equals(destination))return R.drawable.xena_nav_movies;
        if(SERIES.equals(destination))return R.drawable.xena_nav_series;
        if(FAV.equals(destination))return R.drawable.xena_nav_favorites;
        if(GAMES.equals(destination))return R.drawable.xena_nav_games;
        if(SEARCH.equals(destination))return R.drawable.xena_nav_search;
        if(LIST.equals(destination))return R.drawable.xena_nav_menu;
        return R.drawable.xena_nav_options;
    }
    private ImageView xenaNavImage(String destination,int size){
        ImageView image=new ImageView(this);
        image.setImageResource(xenaNavIcon(destination));
        image.setScaleType(ImageView.ScaleType.FIT_CENTER);
        image.setPadding(dp(2),dp(1),dp(2),dp(1));
        return image;
    }
'''
s=replace_once(s,marker,helper+marker,'nav helper')
s=replace_once(s,'TextView mark=text(icons[i],22,selected?MINT:MUTED,true);mark.setGravity(Gravity.CENTER);cell.addView(mark);',
 'ImageView mark=xenaNavImage(dest,29);cell.addView(mark,lp(37,31));','dock icons')
s=replace_once(s,'TextView item=text(icons[i]+dest,13,selected?WHITE:MUTED,selected);\n            item.setGravity(Gravity.CENTER_VERTICAL);item.setPadding(dp(12),0,dp(6),0);',
 '''LinearLayout item=row();item.setPadding(dp(9),0,dp(6),0);
            item.addView(xenaNavImage(dest,30),lp(37,37));
            TextView title=text(dest,13,selected?WHITE:MUTED,selected);
            item.addView(title,new LinearLayout.LayoutParams(0,-2,1));''','sidebar icons')
p.write_text(s)

p=java/'FullScreenPlayerActivity.java';s=p.read_text()
s=replace_once(s,'    private VLCVideoLayout videoSurface;', '''    private VLCVideoLayout videoSurface;
    private VLCVideoLayout secondSurface;
    private MediaPlayer secondPlayer;
    private LinearLayout splitHolder;
    private FrameLayout firstPane,secondPane;
    private ChannelStore.Channel secondChannel;
    private boolean splitEnabled=false,selectingSecond=false;
    private int audiblePane=1;
''','split fields')
s=replace_once(s,'        screen.addView(videoSurface,new FrameLayout.LayoutParams(-1,-1));', '''        screen.addView(videoSurface,new FrameLayout.LayoutParams(-1,-1));
        splitHolder=new LinearLayout(this);
        splitHolder.setOrientation(LinearLayout.HORIZONTAL);
        splitHolder.setVisibility(View.GONE);
        firstPane=new FrameLayout(this);
        secondPane=new FrameLayout(this);
        splitHolder.addView(firstPane,new LinearLayout.LayoutParams(0,-1,1));
        splitHolder.addView(secondPane,new LinearLayout.LayoutParams(0,-1,1));
        secondSurface=new VLCVideoLayout(this);
        secondSurface.setBackground(new GalaxyBackground(this,0xff080a1c));
        secondPane.addView(secondSurface,new FrameLayout.LayoutParams(-1,-1));
        firstPane.setOnClickListener(v->setAudible(1));
        secondPane.setOnClickListener(v->setAudible(2));
        screen.addView(splitHolder,new FrameLayout.LayoutParams(-1,-1));''','split layout')
s=replace_once(s,'        screen.addView(controls,atTopRight(271,51,8,8));', '''        Button split=button("▣ Dupla");split.setOnClickListener(v->{
            if(splitEnabled){disableSplit();split.setText("▣ Dupla");}
            else{enableSplit();split.setText("✕ Dupla");}
        });
        LinearLayout.LayoutParams spl=lp(91,41);spl.leftMargin=dp(5);controls.addView(split,spl);
        Button audio=button("♫ 1");audio.setOnClickListener(v->{
            setAudible(audiblePane==1?2:1);audio.setText("♫ "+audiblePane);
        });
        LinearLayout.LayoutParams apl=lp(55,41);apl.leftMargin=dp(5);controls.addView(audio,apl);
        screen.addView(controls,atTopRight(425,51,8,8));''','split controls')
s=replace_once(s,'        current=item;exhaustedSources=false;store.seen(item.url);', '''        if(selectingSecond){selectingSecond=false;playSecond(item);setGuide(false);return;}
        current=item;exhaustedSources=false;store.seen(item.url);''','second selection')
s=replace_once(s,'    private void stopVideo(){', '''    private void enableSplit(){
        if(splitEnabled)return;
        splitEnabled=true;
        // Move a superfície existente: não interrompe a reprodução principal.
        if(videoSurface.getParent() instanceof android.view.ViewGroup)
            ((android.view.ViewGroup)videoSurface.getParent()).removeView(videoSurface);
        firstPane.addView(videoSurface,new FrameLayout.LayoutParams(-1,-1));
        splitHolder.setVisibility(View.VISIBLE);
        setAudible(1);
        selectingSecond=true;
        setGuide(true);
        message("Escolha o segundo canal no guia.");
    }
    private void playSecond(ChannelStore.Channel item){
        secondChannel=item;
        stopSecond();
        try{
            if(engine==null)return;
            secondPlayer=new MediaPlayer(engine);
            secondPlayer.attachViews(secondSurface,null,false,false);
            Media m=new Media(engine,Uri.parse(item.url));
            m.addOption(":network-caching=2000");
            secondPlayer.setMedia(m);m.release();
            secondPlayer.setVolume(audiblePane==2?100:0);
            secondPlayer.play();
            message("Tela dupla: "+current.name+" | "+item.name);
        }catch(Exception e){message("Segundo canal indisponível.");stopSecond();}
    }
    private void setAudible(int which){
        audiblePane=which;
        if(player!=null)player.setVolume(which==1?100:0);
        if(secondPlayer!=null)secondPlayer.setVolume(which==2?100:0);
    }
    private void stopSecond(){
        if(secondPlayer!=null){
            try{secondPlayer.stop();secondPlayer.detachViews();}catch(Exception ignored){}
            secondPlayer.release();secondPlayer=null;
        }
    }
    private void disableSplit(){
        if(!splitEnabled)return;
        selectingSecond=false;splitEnabled=false;stopSecond();secondChannel=null;
        if(videoSurface.getParent() instanceof android.view.ViewGroup)
            ((android.view.ViewGroup)videoSurface.getParent()).removeView(videoSurface);
        screen.addView(videoSurface,0,new FrameLayout.LayoutParams(-1,-1));
        splitHolder.setVisibility(View.GONE);
        setAudible(1);
    }
    private void stopVideo(){''','split methods')
s=replace_once(s,'    @Override protected void onStop(){super.onStop();stopVideo();}',
 '    @Override protected void onStop(){super.onStop();stopSecond();stopVideo();}','lifecycle stop')
s=replace_once(s,'    @Override protected void onRestart(){super.onRestart();if(current!=null&&videoSurface!=null)start(current);}',
 '    @Override protected void onRestart(){super.onRestart();if(current!=null&&videoSurface!=null)start(current);if(splitEnabled&&secondChannel!=null)playSecond(secondChannel);}','lifecycle restart')
s=replace_once(s,'        if(store!=null)store.close();super.onDestroy();}',
 '        stopSecond();if(store!=null)store.close();super.onDestroy();}','lifecycle destroy')
p.write_text(s)
print('PATCH OK: 9 ícones integrados, navegação adaptativa e 2 MediaPlayers LibVLC com áudio exclusivo.')
