#!/usr/bin/env python3
"""Adiciona controles inferiores e duplo toque ao player LibVLC da XenaTV 6.9.
Executar depois de patch_xenatv_69_integrada.py no projeto restaurado.
"""
from pathlib import Path
p=Path('xena-premium/XenaTV_Android/app/src/main/java/br/com/xenatv/app/FullScreenPlayerActivity.java')
s=p.read_text(encoding='utf-8')
def sub(old,new,tag):
 global s
 if s.count(old)!=1:raise RuntimeError(f'{tag}: esperado 1, achado {s.count(old)}')
 s=s.replace(old,new,1)
sub('import android.widget.ScrollView;', 'import android.widget.ScrollView;\nimport android.widget.SeekBar;\nimport android.widget.HorizontalScrollView;', 'seek bar import') if 'import android.widget.HorizontalScrollView;' not in s else sub('import android.widget.ScrollView;', 'import android.widget.ScrollView;\nimport android.widget.SeekBar;', 'seek bar import')
sub('private LinearLayout side, channelRows, categories, controls;', '''private LinearLayout side, channelRows, categories, controls;
    private LinearLayout playerBar;
    private SeekBar progressBar,volumeBar;
    private TextView timeLabel;
    private boolean userSeeking=false;
    private int playerVolume=85;
    private float playerSpeed=1f;
    private long lastTapAt=0;
    private float lastTapX=0f;
    private final Runnable progressTicker=new Runnable(){
        @Override public void run(){
            if(screen==null||isFinishing())return;
            refreshProgress();
            screen.postDelayed(this,800);
        }
    };''','player state')
sub('''        if(showGuide!=null&&"TV".equals(kind)){''','''        if(playerBar!=null){playerBar.animate().cancel();playerBar.animate().alpha(0f).setDuration(180)
            .withEndAction(()->{if(playerBar!=null&&!open&&playerBar.getAlpha()<0.1f)playerBar.setVisibility(View.GONE);}).start();}
        if(showGuide!=null&&"TV".equals(kind)){''','hide bottom')
sub('''        if(showGuide!=null&&"TV".equals(kind)&&!open){''','''        if(playerBar!=null){playerBar.animate().cancel();playerBar.setVisibility(View.VISIBLE);
            playerBar.animate().alpha(1f).setDuration(160).start();}
        if(showGuide!=null&&"TV".equals(kind)&&!open){''','show bottom')
sub('''        View tapArea=new View(this);tapArea.setClickable(true);tapArea.setOnClickListener(v->showChrome());''', '''        View tapArea=new View(this);
        tapArea.setClickable(true);
        tapArea.setOnTouchListener((v,event)->{
            if(event.getAction()!=android.view.MotionEvent.ACTION_UP)return true;
            long now=android.os.SystemClock.uptimeMillis();
            float x=event.getX();
            if(now-lastTapAt<340&&Math.abs(x-lastTapX)<dp(95)){
                lastTapAt=0;
                if(x<v.getWidth()*0.44f)skipSeconds(-10);
                else if(x>v.getWidth()*0.56f)skipSeconds(10);
                else showChrome();
            }else{lastTapAt=now;lastTapX=x;showChrome();}
            return true;
        });''','double tap')
sub('''        screen.addView(controls,atTopRight(425,51,8,8));''','''        screen.addView(controls,atTopRight(425,51,8,8));
        buildPlayerBar();
        screen.post(progressTicker);''','bottom bar insertion')
sub('''        sp.bottomMargin=dp(14);sp.rightMargin=dp(12);screen.addView(state,sp);''','''        sp.bottomMargin=dp(108);sp.rightMargin=dp(12);screen.addView(state,sp);''','status location')
sub('''    private void message(String text){''', '''    private boolean canSeek(){return player!=null&&player.getLength()>0&&player.isSeekable();}
    private void skipSeconds(int seconds){
        if(!canSeek()){message("Este vídeo não permite avançar ou voltar.");showChrome();return;}
        long length=player.getLength();
        long target=Math.max(0,Math.min(length,player.getTime()+seconds*1000L));
        player.setTime(target);showChrome();
    }
    private String timeFmt(long milliseconds){
        long sec=Math.max(0,milliseconds/1000);
        return String.format(java.util.Locale.ROOT,"%02d:%02d:%02d",sec/3600,(sec/60)%60,sec%60);
    }
    private void refreshProgress(){
        if(progressBar==null||timeLabel==null)return;
        long length=player==null?0:player.getLength();
        long now=player==null?0:Math.max(0,player.getTime());
        boolean seeking=canSeek();
        progressBar.setEnabled(seeking);
        if(!userSeeking){progressBar.setProgress(length>0?(int)Math.min(1000,now*1000/length):0);}
        timeLabel.setText(timeFmt(now)+" / "+(length>0?timeFmt(length):"AO VIVO"));
    }
    private void applyVolume(){
        if(player!=null)player.setVolume(audiblePane==1?playerVolume:0);
        if(secondPlayer!=null)secondPlayer.setVolume(audiblePane==2?playerVolume:0);
    }
    private void buildPlayerBar(){
        playerBar=col();playerBar.setPadding(dp(10),dp(8),dp(10),dp(8));
        playerBar.setBackground(cosmicControlsGradient());
        LinearLayout seekRow=row();
        timeLabel=text("00:00:00 / 00:00:00",11,WHITE,false);
        progressBar=new SeekBar(this);progressBar.setMax(1000);progressBar.setEnabled(false);
        seekRow.addView(timeLabel,lp(132,36));
        seekRow.addView(progressBar,new LinearLayout.LayoutParams(0,dp(36),1));
        progressBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            @Override public void onStartTrackingTouch(SeekBar b){userSeeking=true;showChrome();}
            @Override public void onProgressChanged(SeekBar b,int value,boolean fromUser){
                if(fromUser&&player!=null&&player.getLength()>0)timeLabel.setText(timeFmt(player.getLength()*value/1000)+" / "+timeFmt(player.getLength()));
            }
            @Override public void onStopTrackingTouch(SeekBar b){
                if(canSeek())player.setTime(player.getLength()*b.getProgress()/1000);
                userSeeking=false;showChrome();
            }
        });
        playerBar.addView(seekRow,lp(-1,40));
        HorizontalScrollView horizontal=new HorizontalScrollView(this);
        horizontal.setHorizontalScrollBarEnabled(false);
        LinearLayout buttons=row();buttons.setPadding(0,0,0,dp(2));
        Button play=button("⏯ Reproduzir/Pausar");play.setOnClickListener(v->{
            if(player==null)return;
            if(player.isPlaying())player.pause();else player.play();showChrome();
        });buttons.addView(play,lp(154,40));
        Button minus=button("↶ 10s");minus.setOnClickListener(v->skipSeconds(-10));buttons.addView(minus,lp(74,40));
        Button plus=button("10s ↷");plus.setOnClickListener(v->skipSeconds(10));buttons.addView(plus,lp(74,40));
        Button episodes=button("☷ Episódios");episodes.setOnClickListener(v->{
            if("TV".equals(kind)||"MOVIES".equals(kind)){
                message("Seleção de episódios disponível para séries.");return;
            }
            setGuide(true);
        });buttons.addView(episodes,lp(110,40));
        Button speed=button("1×");speed.setOnClickListener(v->{
            playerSpeed=playerSpeed==1f?1.25f:playerSpeed==1.25f?1.5f:playerSpeed==1.5f?2f:1f;
            if(player!=null)player.setRate(playerSpeed);
            speed.setText(playerSpeed+"×");showChrome();
        });buttons.addView(speed,lp(65,40));
        TextView loud=text("  🔊",15,WHITE,false);buttons.addView(loud,lp(39,40));
        volumeBar=new SeekBar(this);volumeBar.setMax(100);volumeBar.setProgress(playerVolume);
        volumeBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
            @Override public void onProgressChanged(SeekBar b,int value,boolean user){if(user){playerVolume=value;applyVolume();showChrome();}}
            @Override public void onStartTrackingTouch(SeekBar b){}
            @Override public void onStopTrackingTouch(SeekBar b){}
        });buttons.addView(volumeBar,lp(116,40));
        horizontal.addView(buttons);
        playerBar.addView(horizontal,lp(-1,45));
        FrameLayout.LayoutParams params=new FrameLayout.LayoutParams(-1,dp(100),Gravity.BOTTOM);
        params.leftMargin=dp(8);params.rightMargin=dp(8);params.bottomMargin=dp(8);
        screen.addView(playerBar,params);
    }
    private void message(String text){''','player bar methods')
sub('''            currentPlayer.setMedia(m);m.release();currentPlayer.play();''','''            currentPlayer.setMedia(m);m.release();currentPlayer.play();
            applyVolume();''','volume on play')
sub('''        if(player!=null)player.setVolume(which==1?100:0);
        if(secondPlayer!=null)secondPlayer.setVolume(which==2?100:0);''','''        applyVolume();''','volume on switching audio')
sub('''            secondPlayer.setVolume(audiblePane==2?100:0);''','''            secondPlayer.setVolume(audiblePane==2?playerVolume:0);''','second player volume')
sub('''    @Override protected void onDestroy(){if(screen!=null)screen.removeCallbacks(hideChrome);''','''    @Override protected void onDestroy(){if(screen!=null){screen.removeCallbacks(hideChrome);screen.removeCallbacks(progressTicker);}''','ticker cleanup')
p.write_text(s,encoding='utf-8')
print('PLAYER 6.9: barra inferior + progresso/seek + 10s/duplo toque + pausa + velocidade + volume + acesso ao guia.')
