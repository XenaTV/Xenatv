package br.com.xenatv.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.videolan.libvlc.LibVLC;
import org.videolan.libvlc.Media;
import org.videolan.libvlc.MediaPlayer;
import org.videolan.libvlc.util.VLCVideoLayout;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Xena TV: player local de streams públicos e amostras HLS, sem retransmissão. */
public class MainActivity extends Activity {
    private static final int BG = 0xff0c0816, PANEL = 0xff171027, PANEL2 = 0xff221633;
    private static final int PURPLE = 0xffa45aff, GREEN = 0xff3aff9d, WHITE = 0xfff7f4ff, MUTED = 0xffa99cbd;
    private final List<Channel> channels = new ArrayList<>();
    private final List<Channel> visible = new ArrayList<>();
    private LinearLayout root, list, home, overlay, playerContainer;
    private EditText search;
    private TextView count, playbackStatus;
    private String filter = "Todos";
    private LibVLC libVlc;
    private MediaPlayer mediaPlayer;
    private VLCVideoLayout vlcView;
    private SharedPreferences prefs;
    private Channel current;

    private static class Channel {
        final String title, kind, description, stream, official, initials;
        final int shade;
        Channel(String name, String type, String description, String stream, String official, String initials, int shade) {
            this.title=name;this.kind=type;this.description=description;this.stream=stream;this.official=official;this.initials=initials;this.shade=shade;
        }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        prefs=getSharedPreferences("xena", Context.MODE_PRIVATE);
        initChannels();
        createUI();
    }
    private void initChannels() {
        // Streams listados em domínios institucionais oficiais. Disponibilidade pode mudar.
        channels.add(new Channel("TV Câmara", "TV ao vivo", "Canal público • Legislativo", "https://stream3.camara.gov.br/tv1/manifest.m3u8", "https://www.camara.leg.br/tv/", "CÂ", PURPLE));
        channels.add(new Channel("TV Senado", "TV ao vivo", "Canal público • Legislativo", "https://tv.senado.leg.br/hls/tv-senado.m3u8", "https://www12.senado.leg.br/tv", "SE", GREEN));
        channels.add(new Channel("TV Brasil", "TV ao vivo", "Canal público • Cultura e notícias", "https://tvbrasil-stream.ebc.com.br/index.m3u8", "https://tvbrasil.ebc.com.br/", "BR", 0xff26baff));
        // Fontes HLS públicas de diagnóstico: não são canais ao vivo.
        channels.add(new Channel("Teste do player • Mux", "Demonstração", "Big Buck Bunny • HLS com qualidade adaptável", "https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8", "https://test-streams.mux.dev/", "▶", 0xfff1b856));
        channels.add(new Channel("Teste do player • Apple", "Demonstração", "Vídeo HLS de referência para diagnóstico", "https://devstreaming-cdn.apple.com/videos/streaming/examples/img_bipbop_adv_example_ts/master.m3u8", "https://developer.apple.com/streaming/", "4K", 0xffb87afa));
    }
    private int dp(float n) {return (int)(n*getResources().getDisplayMetrics().density+0.5f);}
    private GradientDrawable bg(int color, int r, int stroke) {
        GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(r));
        if(stroke!=0)g.setStroke(dp(1),stroke);return g;
    }
    private GradientDrawable glow() {
        GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xff712bcb, 0xff2c154c, 0xff17251d});
        g.setCornerRadius(dp(24));g.setStroke(dp(1),0xff8154aa);return g;
    }
    private TextView txt(String t,int sz,int color,boolean bold) {
        TextView v=new TextView(this);v.setText(t);v.setTextSize(sz);v.setTextColor(color);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return v;
    }
    private LinearLayout col() {LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout row() {LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private LinearLayout.LayoutParams lp(int w,int h) {return new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));}
    private void gap(LinearLayout parent,int n){View v=new View(this);parent.addView(v,lp(1,n));}
    private Button button(String t, int color, int textColor) {
        Button b=new Button(this);b.setAllCaps(false);b.setText(t);b.setTextColor(textColor);b.setTextSize(13);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setBackground(bg(color,12,0));b.setPadding(dp(9),0,dp(9),0);return b;
    }
    private void createUI() {
        FrameLayout stage=new FrameLayout(this);stage.setBackgroundColor(BG);setContentView(stage);
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);stage.addView(sc,new FrameLayout.LayoutParams(-1,-1));
        home=col();home.setPadding(dp(17),dp(20),dp(17),dp(24));sc.addView(home);
        LinearLayout header=row();
        ImageView icon=new ImageView(this);icon.setImageResource(br.com.xenatv.app.R.drawable.xena_icon);icon.setScaleType(ImageView.ScaleType.CENTER_CROP);
        header.addView(icon,lp(52,52));
        LinearLayout brand=col();brand.setPadding(dp(12),0,0,0);brand.addView(txt("XENA  TV",26,WHITE,true));brand.addView(txt("ULTRA  •  MOTOR VLC",10,GREEN,true));
        header.addView(brand);home.addView(header);gap(home,19);
        LinearLayout hero=col();hero.setPadding(dp(19),dp(20),dp(19),dp(20));hero.setBackground(glow());
        hero.addView(txt("📺  TV AO VIVO",13,GREEN,true));gap(hero,7);
        hero.addView(txt("Seus canais, em primeiro lugar.",22,WHITE,true));gap(hero,7);
        hero.addView(txt("Toque em um canal para iniciar diretamente. Qualidade conforme a fonte original.",12,0xffe0d4ee,false));
        home.addView(hero);gap(home,18);
        search=new EditText(this);search.setSingleLine(true);search.setTextColor(WHITE);search.setHintTextColor(MUTED);search.setTextSize(15);
        search.setHint("⌕  Buscar canais ou testes");search.setPadding(dp(15),dp(11),dp(15),dp(11));search.setBackground(bg(PANEL2,14,0xff4a2867));home.addView(search,lp(-1,49));
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int start,int count,int after){} public void onTextChanged(CharSequence s,int st,int b,int c){render();}public void afterTextChanged(Editable e){}});
        gap(home,12);
        HorizontalScrollView slider=new HorizontalScrollView(this);slider.setHorizontalScrollBarEnabled(false);LinearLayout chipRow=row();
        for(String f:new String[]{"Todos","TV ao vivo","Demonstração","Favoritos"}){
            Button b=button(f,0xff2b2040,WHITE);LinearLayout.LayoutParams cl=lp(-2,40);cl.rightMargin=dp(8);chipRow.addView(b,cl);b.setOnClickListener(v->{filter=f;render();});
        }
        slider.addView(chipRow);home.addView(slider);gap(home,20);
        LinearLayout bar=row();bar.addView(txt("CANAIS & TRANSMISSÕES",14,WHITE,true));
        count=txt("",12,GREEN,true);count.setGravity(Gravity.RIGHT);bar.addView(count,new LinearLayout.LayoutParams(0,-2,1));home.addView(bar);
        gap(home,10);
        list=col();home.addView(list);
        gap(home,18);
        home.addView(txt("SUGESTÕES OFICIAIS",13,WHITE,true));gap(home,10);
        LinearLayout suggest=row();
        Button yt=button("▶  YouTube",0xff322044,WHITE);Button globo=button("◉  Globoplay",0xff322044,WHITE);
        LinearLayout.LayoutParams s1=new LinearLayout.LayoutParams(0,dp(49),1);s1.rightMargin=dp(7);suggest.addView(yt,s1);suggest.addView(globo,new LinearLayout.LayoutParams(0,dp(49),1));
        yt.setOnClickListener(v->openWeb("https://www.youtube.com/"));globo.setOnClickListener(v->openWeb("https://globoplay.globo.com/"));home.addView(suggest);
        gap(home,20);
        TextView note=txt("Fontes públicas e demonstrações • a reprodução depende do servidor e da autorização de uso. Não retransmitimos sinais. Nenhuma senha IPTV foi incluída.",11,MUTED,false);
        home.addView(note);
        overlay=col();overlay.setBackgroundColor(0xff090511);overlay.setVisibility(View.GONE);stage.addView(overlay,new FrameLayout.LayoutParams(-1,-1));
        render();
    }
    private boolean favorite(Channel c) {return prefs.getBoolean("fav_"+c.title,false);}
    private void render(){if(list==null)return;list.removeAllViews();visible.clear();
        String query=search.getText().toString().trim().toLowerCase(Locale.ROOT);
        for(Channel c:channels){if(!filter.equals("Todos")&&!filter.equals(c.kind)&&!(filter.equals("Favoritos")&&favorite(c)))continue;
            if(!query.isEmpty()&&!c.title.toLowerCase(Locale.ROOT).contains(query)&&!c.description.toLowerCase(Locale.ROOT).contains(query))continue;
            visible.add(c);
            LinearLayout item=row();item.setPadding(dp(12),dp(10),dp(8),dp(10));item.setBackground(bg(PANEL,15,0xff47335c));
            TextView badge=txt(c.initials,16,c.shade,true);badge.setGravity(Gravity.CENTER);badge.setBackground(bg(PANEL2,13,c.shade));item.addView(badge,lp(55,55));
            LinearLayout info=col();info.setPadding(dp(12),0,dp(4),0);info.addView(txt(c.title,16,WHITE,true));gap(info,4);info.addView(txt(c.description,11,MUTED,false));
            item.addView(info,new LinearLayout.LayoutParams(0,-2,1));
            TextView star=txt(favorite(c)?"★":"☆",25,favorite(c)?GREEN:MUTED,false);star.setGravity(Gravity.CENTER);item.addView(star,lp(40,55));
            star.setOnClickListener(v->{prefs.edit().putBoolean("fav_"+c.title,!favorite(c)).apply();render();});
            item.setOnClickListener(v->play(c));
            LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=dp(9);list.addView(item,p);
        }
        count.setText(visible.size()+" opções");
        if(visible.isEmpty()){TextView empty=txt("Nenhum canal encontrado para essa busca.",14,MUTED,false);empty.setPadding(dp(6),dp(24),0,dp(25));list.addView(empty);}
    }
    private void play(Channel c){current=c;overlay.removeAllViews();overlay.setVisibility(View.VISIBLE);
        LinearLayout title=row();title.setPadding(dp(15),dp(13),dp(12),dp(10));
        Button back=button("‹ Voltar",0xff33234c,WHITE);title.addView(back,lp(92,44));back.setOnClickListener(v->closePlayer());
        LinearLayout names=col();names.setPadding(dp(12),0,0,0);names.addView(txt(c.title,17,WHITE,true));names.addView(txt("LIBVLC • reprodução direta",10,GREEN,true));title.addView(names);overlay.addView(title);
        FrameLayout videoFrame=new FrameLayout(this);videoFrame.setBackgroundColor(Color.BLACK);
        overlay.addView(videoFrame,new LinearLayout.LayoutParams(-1,0,1));
        vlcView=new VLCVideoLayout(this);videoFrame.addView(vlcView,new FrameLayout.LayoutParams(-1,-1));
        playbackStatus=txt("Conectando ao sinal...",13,GREEN,false);playbackStatus.setGravity(Gravity.CENTER);playbackStatus.setPadding(dp(10),dp(10),dp(10),dp(10));overlay.addView(playbackStatus);
        LinearLayout controls=row();controls.setPadding(dp(10),0,dp(10),dp(12));
        Button retry=button("↻  Reconectar",0xff472466,WHITE);Button official=button("↗  Fonte oficial",0xff1b4235,GREEN);
        LinearLayout.LayoutParams half=new LinearLayout.LayoutParams(0,dp(49),1);half.rightMargin=dp(7);controls.addView(retry,half);controls.addView(official,new LinearLayout.LayoutParams(0,dp(49),1));overlay.addView(controls);
        retry.setOnClickListener(v->play(c));official.setOnClickListener(v->openWeb(c.official));
        try{
            if(libVlc==null){ArrayList<String> options=new ArrayList<>();options.add("--network-caching=1500");options.add("--http-reconnect");libVlc=new LibVLC(this,options);}
            if(mediaPlayer!=null){mediaPlayer.stop();if(mediaPlayer.getVLCVout().areViewsAttached())mediaPlayer.detachViews();mediaPlayer.release();}
            mediaPlayer=new MediaPlayer(libVlc);
            mediaPlayer.attachViews(vlcView,null,false,false);
            final MediaPlayer active=mediaPlayer;
            active.setEventListener(event->runOnUiThread(()->{
                if(active!=mediaPlayer||playbackStatus==null)return;
                if(event.type==MediaPlayer.Event.Playing)playbackStatus.setText("● Reproduzindo · qualidade da fonte");
                else if(event.type==MediaPlayer.Event.Buffering)playbackStatus.setText("● Carregando vídeo...");
                else if(event.type==MediaPlayer.Event.EncounteredError)playbackStatus.setText("Não foi possível reproduzir. Tente Reconectar ou Fonte oficial.");
                else if(event.type==MediaPlayer.Event.EndReached)playbackStatus.setText("Vídeo encerrado.");
            }));
            Media media=new Media(libVlc,Uri.parse(c.stream));
            media.addOption(":network-caching=1500");
            media.addOption(":http-reconnect=true");
            active.setMedia(media);media.release();active.play();
        }catch(Exception e){playbackStatus.setText("Falha ao iniciar: "+e.getClass().getSimpleName());}
    }
    private void closePlayer(){if(mediaPlayer!=null){mediaPlayer.stop();if(mediaPlayer.getVLCVout().areViewsAttached())mediaPlayer.detachViews();mediaPlayer.release();mediaPlayer=null;}
        if(overlay!=null){overlay.removeAllViews();overlay.setVisibility(View.GONE);}vlcView=null;current=null;}
    private void openWeb(String url){try{Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(url));i.setPackage("com.brave.browser");startActivity(i);}catch(Exception e){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception ignored){Toast.makeText(this,"Navegador indisponível",Toast.LENGTH_SHORT).show();}}}
    @Override public void onBackPressed(){if(overlay!=null&&overlay.getVisibility()==View.VISIBLE){closePlayer();return;}super.onBackPressed();}
    @Override protected void onDestroy(){closePlayer();if(libVlc!=null){libVlc.release();libVlc=null;}super.onDestroy();}
}
