# Xena TV – Android LibVLC (teste 1)

Projeto Android **nativo** com LibVLC 3.7.7. Canais **já pré-cadastrados**: TV Câmara, TV Senado, TV Brasil, além de dois vídeos HLS públicos para testar o motor. Cada canal exibe aviso de conexão, botão de tentar novamente e link para a página oficial. Há busca, favoritos locais e atalhos para YouTube e Globoplay, tudo em roxo + verde néon.

## IMPORTANTE

**Este ZIP é o projeto-fonte, não um APK instalado ou validado.** O ambiente que o criou não tem Android SDK nem Internet de compilação. O APK será gerado quando o GitHub Actions ou o Android Studio fizerem a compilação. O APK não foi executado num celular ainda.

- A versão 1 usa transmissões **diretas em domínios institucionais**, citadas em diretórios de canais públicos, mas a disponibilidade, a política de incorporação e as permissões de reprodução precisam ser confirmadas pelos provedores. Não são retransmitidas pelo app.
- Os dois itens “Teste do player” são demonstrações HLS de terceiros, **não canais ao vivo**, e são úteis para diferenciar problemas do player de problemas do servidor.
- Links de terceiros podem sair do ar, exigir token, restringir domínio/dispositivo ou alterar formato; nenhum aplicativo pode prometer fazê-los funcionar sempre.
- Nenhuma credencial IPTV privada está incluída. Não coloque senhas em um APK que será compartilhado.
- O app abre as páginas oficiais no Brave quando ele estiver instalado.

## Compilar no Android Studio

Abra a pasta do projeto como projeto Gradle. Use JDK 17, Android SDK Platform 35, Android Gradle Plugin 8.7.3 e Gradle 8.9. Rode `gradle assembleDebug`. O APK aparecerá em `app/build/outputs/apk/debug/app-debug.apk`.

## Compilar no GitHub Actions (sem Android Studio)

Envie os arquivos do projeto para um repositório GitHub e use `.github/workflows/build-android.yml`. Vá em **Actions → Xena TV – APK Android → Run workflow**. Quando o workflow acabar com ✓, abra o run, seção **Artifacts**, baixe `XenaTV-Android-debug-apk` e extraia o APK. O GitHub pode pedir confirmação de segurança ao instalar um APK de teste.

Se precisar publicar separadamente do site da Xena TV, use uma branch ou repositório `xena-tv-android` para não alterar seu GitHub Pages atual.

## Licença

Este aplicativo usa **LibVLC**, projeto VideoLAN sob LGPL 2.1; veja https://www.videolan.org/ e https://github.com/videolan/vlc-android. Este código não contém o VLC original, apenas sua dependência declarada do Maven Central. Marcas, vídeos e transmissões de terceiros permanecem sob direitos de seus titulares.
